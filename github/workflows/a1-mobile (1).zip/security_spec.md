# A1 MOBILE — Firestore Security Specification

## 1. Data Invariants

1. **Zero-Trust Role Authority**: Authorization NEVER trusts client-writable `user_profiles/{userId}.role`. Roles and capabilities are resolved exclusively from:
   - Verified bootstrap admin email token (`sanayaikhom62@gmail.com`, `email_verified == true`)
   - `/admins/{userId}` trusted registry
   - `/staff/{userId}` trusted registry (`active == true` and explicit `permissions` flags)
2. **Customer & Public Storefront Boundaries**:
   - Unauthenticated visitors and `customer` users may only read published catalog products (`inventory` where `isPublished == true`).
   - Customers may only read, create (`status: "pending"`), and cancel (`pending`/`confirmed` -> `cancelled`) their OWN bookings (`userId == request.auth.uid`).
   - Customers CANNOT list store-wide analytics (`user_profiles`, `booking_metrics`), CANNOT read other users' private info (`user_private`, other users' `bookings`), CANNOT edit inventory, and CANNOT read/write `/staff` or `/admins`.
3. **Scoped Staff Permissions**:
   - `manageInventory`: Read unpublished inventory and create/update/delete `inventory/{itemId}`.
   - `manageBookings`: Read all `bookings` and transition `status`/schedule fields on customer bookings & `booking_metrics`.
   - `viewAnalytics`: Read `user_profiles` and `booking_metrics` store-wide.
   - Ordinary `staff` CANNOT access `/staff` management writes, `/admins`, or `user_private` of other users, and CANNOT promote themselves or anyone else to `admin`.
4. **PII Isolation**: `user_private/{userId}` is accessible strictly to the owning user (`isOwner(userId)`) or `isAdmin()`.
5. **Atomic Booking-Metric Synchronization**: Creating a `booking_metrics/{bookingId}` document requires `existsAfter()` of its paired `bookings/{bookingId}` document.
6. **Temporal Integrity**: All `createdAt`, `updatedAt`, and `lastActiveAt` timestamps must match `request.time`; `createdAt` and `userId`/`uid` are immutable after creation.

## 2. Adversarial Payloads Blocked (`PERMISSION_DENIED`)

1. **Identity Spoofing on Booking Create**: Authenticated user `alice` submits `bookings/b1` with `userId: "bob"`.
2. **Self-Admin Role Escalation on Profile Create**: Non-admin user `alice` creates `user_profiles/alice` with `role: "admin"` or `"staff"`.
3. **Role Mutation on Profile Update**: Non-admin user `alice` updates `user_profiles/alice` changing `role` to `"admin"`.
4. **Staff Self-Promotion**: Active staff member `bob` tries creating `/admins/bob` or modifying `/staff/bob` permissions.
5. **Customer/Unauthorized Inventory Edit**: Customer `alice` (or staff without `manageInventory`) tries updating `inventory/item1` price/stock.
6. **Customer Store-Wide Analytics Scraping**: Customer `alice` attempts `list` on `/user_profiles` or `/booking_metrics`.
7. **PII Blanket Read on `user_private`**: Customer or Staff `alice` attempts `get` or `list` on `user_private/bob`.
8. **PII List Scraping on `bookings`**: Customer or Staff without `manageBookings` queries `/bookings` without `where("userId", "==", uid)`.
9. **Terminal State Re-opening**: Customer `alice` updates `bookings/b1` (`completed`) back to `pending`.
10. **ID Poisoning / Shadow Field Injection**: Attacker writes >128-char doc ID or extra undeclared field on `inventory`, `staff`, or `bookings`.
11. **Suspended Staff Access**: Staff member with `staff/{uid}.active == false` attempts inventory or booking management write.
12. **Unverified Email Admin Spoof**: Token with `email: "sanayaikhom62@gmail.com"` and `email_verified: false` attempts an admin write.
