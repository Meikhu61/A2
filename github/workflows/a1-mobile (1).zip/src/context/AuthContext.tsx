import React, { createContext, useCallback, useContext, useEffect, useState } from 'react';
import {
  onAuthStateChanged,
  signInWithPopup,
  signOut,
  type User,
} from 'firebase/auth';
import {
  doc,
  getDoc,
  onSnapshot,
  serverTimestamp,
  setDoc,
  Timestamp,
  updateDoc,
} from 'firebase/firestore';
import {
  auth,
  BOOTSTRAP_ADMIN_EMAIL,
  db,
  googleProvider,
  handleFirestoreError,
  OperationType,
} from '../lib/firebase';
import {
  EMPTY_CAPABILITIES,
  resolveRoleAndCapabilities,
} from '../lib/rbac';
import {
  AccessCapabilities,
  clampStr,
  SCHEMA_LIMITS,
  StaffRecord,
  StaffRoleLabel,
  UserPrivate,
  UserProfile,
  UserRole,
} from '../types/domain';
import { fetchUserPrivate } from '../services/firestoreService';

interface AuthContextValue {
  user: User | null;
  profile: UserProfile | null;
  privateInfo: UserPrivate | null;
  role: UserRole;
  isAdmin: boolean;
  isBootstrapAdmin: boolean;
  isStaff: boolean;
  staffRecord: StaffRecord | null;
  permissions: AccessCapabilities;
  authReady: boolean;
  signingIn: boolean;
  authError: string | null;
  signInWithGoogle: () => Promise<void>;
  logout: () => Promise<void>;
  refreshPrivateInfo: () => Promise<void>;
}

const AuthContext = createContext<AuthContextValue | null>(null);

function computeInitials(name: string): string {
  const parts = name.trim().split(/\s+/).filter(Boolean);
  if (parts.length === 0) return 'U';
  if (parts.length === 1) return parts[0].slice(0, 2).toUpperCase();
  return `${parts[0][0]}${parts[parts.length - 1][0]}`.toUpperCase();
}

function parseStaffSnapshot(uid: string, data: Record<string, unknown>): StaffRecord {
  const perms = (data.permissions || {}) as Record<string, unknown>;
  return {
    uid: String(data.uid || uid),
    displayName: String(data.displayName || 'Staff Member'),
    email: String(data.email || ''),
    staffRoleLabel: (data.staffRoleLabel as StaffRoleLabel) || 'Operations Staff',
    permissions: {
      manageInventory: Boolean(perms.manageInventory),
      manageBookings: Boolean(perms.manageBookings),
      viewAnalytics: Boolean(perms.viewAnalytics),
    },
    active: Boolean(data.active),
    createdBy: String(data.createdBy || ''),
    createdAt: data.createdAt instanceof Timestamp ? data.createdAt.toDate() : null,
    updatedAt: data.updatedAt instanceof Timestamp ? data.updatedAt.toDate() : null,
  };
}

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [privateInfo, setPrivateInfo] = useState<UserPrivate | null>(null);
  const [role, setRole] = useState<UserRole>('customer');
  const [isAdmin, setIsAdmin] = useState(false);
  const [isBootstrapAdmin, setIsBootstrapAdmin] = useState(false);
  const [isStaff, setIsStaff] = useState(false);
  const [staffRecord, setStaffRecord] = useState<StaffRecord | null>(null);
  const [permissions, setPermissions] = useState<AccessCapabilities>(EMPTY_CAPABILITIES);
  const [authReady, setAuthReady] = useState(false);
  const [signingIn, setSigningIn] = useState(false);
  const [authError, setAuthError] = useState<string | null>(null);

  const applyTrustedRoleState = useCallback(
    (firebaseUser: User, hasAdminDoc: boolean, staffDoc: StaffRecord | null) => {
      const resolved = resolveRoleAndCapabilities({
        email: firebaseUser.email,
        emailVerified: firebaseUser.emailVerified,
        hasAdminDoc,
        staffRecord: staffDoc,
      });
      setRole(resolved.role);
      setIsAdmin(resolved.isAdmin);
      setIsBootstrapAdmin(resolved.isBootstrapAdmin);
      setIsStaff(resolved.isStaff);
      setStaffRecord(staffDoc);
      setPermissions(resolved.permissions);
      return resolved;
    },
    []
  );

  const syncUserDocuments = useCallback(
    async (firebaseUser: User) => {
      const uid = firebaseUser.uid;
      const bootstrapAdmin =
        Boolean(firebaseUser.emailVerified) &&
        firebaseUser.email?.toLowerCase() === BOOTSTRAP_ADMIN_EMAIL;

      const [adminSnapResult, staffSnapResult] = await Promise.allSettled([
        bootstrapAdmin ? Promise.resolve(null) : getDoc(doc(db, 'admins', uid)),
        getDoc(doc(db, 'staff', uid)),
      ]);

      const adminDocExists =
        adminSnapResult.status === 'fulfilled' &&
        adminSnapResult.value !== null &&
        adminSnapResult.value.exists();

      const staffDoc =
        staffSnapResult.status === 'fulfilled' && staffSnapResult.value.exists()
          ? parseStaffSnapshot(uid, staffSnapResult.value.data())
          : null;

      const resolved = applyTrustedRoleState(firebaseUser, adminDocExists, staffDoc);

      const displayName = clampStr(
        firebaseUser.displayName || firebaseUser.email?.split('@')[0] || 'A1 Customer',
        SCHEMA_LIMITS.CUSTOMER_NAME_MAX
      );
      const initials = computeInitials(displayName);
      const profileRef = doc(db, 'user_profiles', uid);
      const privateRef = doc(db, 'user_private', uid);

      try {
        const profileSnap = await getDoc(profileRef);
        if (!profileSnap.exists()) {
          await setDoc(profileRef, {
            uid,
            displayName,
            avatarInitials: initials,
            role: resolved.role,
            isPublicProfile: true,
            totalBookings: 0,
            completedBookings: 0,
            cancelledBookings: 0,
            tradeInCount: 0,
            totalProjectedValue: 0,
            preferredBrand: 'all',
            lastActiveAt: serverTimestamp(),
            createdAt: serverTimestamp(),
            updatedAt: serverTimestamp(),
          });
        } else {
          const existingRole = profileSnap.data()?.role;
          const updates: Record<string, unknown> = {
            displayName,
            avatarInitials: initials,
            lastActiveAt: serverTimestamp(),
            updatedAt: serverTimestamp(),
          };
          // Keep display profile role synced with trusted registry when permitted
          if (existingRole !== resolved.role) {
            updates.role = resolved.role;
          }
          await updateDoc(profileRef, updates);
        }

        const freshSnap = await getDoc(profileRef);
        if (freshSnap.exists()) {
          const d = freshSnap.data();
          setProfile({
            uid: String(d.uid || uid),
            displayName: String(d.displayName || displayName),
            avatarInitials: String(d.avatarInitials || initials),
            // UI role reflects trusted registry, never client-writable profile doc
            role: resolved.role,
            isPublicProfile: true,
            totalBookings: Number(d.totalBookings || 0),
            completedBookings: Number(d.completedBookings || 0),
            cancelledBookings: Number(d.cancelledBookings || 0),
            tradeInCount: Number(d.tradeInCount || 0),
            totalProjectedValue: Number(d.totalProjectedValue || 0),
            preferredBrand: d.preferredBrand || 'all',
          });
        }
      } catch (error) {
        try {
          handleFirestoreError(error, OperationType.WRITE, `user_profiles/${uid}`);
        } catch (wrapped) {
          console.error(wrapped);
        }
      }

      try {
        const privSnap = await getDoc(privateRef);
        const safeEmail = clampStr(
          firebaseUser.email || 'user@a1mobile.local',
          SCHEMA_LIMITS.EMAIL_MAX
        );
        if (!privSnap.exists()) {
          await setDoc(privateRef, {
            uid,
            email: safeEmail,
            phone: '',
            createdAt: serverTimestamp(),
            updatedAt: serverTimestamp(),
          });
        }
        const privData = await fetchUserPrivate(uid);
        setPrivateInfo(privData);
      } catch (error) {
        try {
          handleFirestoreError(error, OperationType.WRITE, `user_private/${uid}`);
        } catch (wrapped) {
          console.error(wrapped);
        }
      }
    },
    [applyTrustedRoleState]
  );

  // Auth listener + initial trusted role verification
  useEffect(() => {
    const unsub = onAuthStateChanged(auth, async (firebaseUser) => {
      if (firebaseUser) {
        await syncUserDocuments(firebaseUser);
        setUser(firebaseUser);
      } else {
        setUser(null);
        setProfile(null);
        setPrivateInfo(null);
        setRole('customer');
        setIsAdmin(false);
        setIsBootstrapAdmin(false);
        setIsStaff(false);
        setStaffRecord(null);
        setPermissions(EMPTY_CAPABILITIES);
      }
      setAuthReady(true);
    });
    return () => unsub();
  }, [syncUserDocuments]);

  // Real-time revocation/permission sync on the user's own trusted /staff/{uid} document
  useEffect(() => {
    if (!authReady || !user) return;
    if (isBootstrapAdmin) return;

    const uid = user.uid;
    let currentAdminDoc = isAdmin;

    const unsubStaff = onSnapshot(
      doc(db, 'staff', uid),
      (snap) => {
        const nextStaff = snap.exists() ? parseStaffSnapshot(uid, snap.data()) : null;
        applyTrustedRoleState(user, currentAdminDoc, nextStaff);
      },
      () => {
        // Ignore transient errors if unmounted during sign-out
      }
    );

    const unsubAdmin = onSnapshot(
      doc(db, 'admins', uid),
      (snap) => {
        currentAdminDoc = snap.exists();
        applyTrustedRoleState(user, currentAdminDoc, staffRecord);
      },
      () => {
        // Ignore
      }
    );

    return () => {
      unsubStaff();
      unsubAdmin();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [authReady, user?.uid, isBootstrapAdmin]);

  const signInWithGoogle = useCallback(async () => {
    setSigningIn(true);
    setAuthError(null);
    try {
      await signInWithPopup(auth, googleProvider);
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Unable to sign in with Google.';
      setAuthError(msg);
    } finally {
      setSigningIn(false);
    }
  }, []);

  const logout = useCallback(async () => {
    setAuthError(null);
    await signOut(auth);
  }, []);

  const refreshPrivateInfo = useCallback(async () => {
    if (!user) return;
    const data = await fetchUserPrivate(user.uid);
    setPrivateInfo(data);
  }, [user]);

  return (
    <AuthContext.Provider
      value={{
        user,
        profile,
        privateInfo,
        role,
        isAdmin,
        isBootstrapAdmin,
        isStaff,
        staffRecord,
        permissions,
        authReady,
        signingIn,
        authError,
        signInWithGoogle,
        logout,
        refreshPrivateInfo,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export function useAuth(): AuthContextValue {
  const ctx = useContext(AuthContext);
  if (!ctx) {
    throw new Error('useAuth must be used inside AuthProvider');
  }
  return ctx;
}
