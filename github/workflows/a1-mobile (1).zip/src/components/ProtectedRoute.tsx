import React from 'react';
import { useAuth } from '../context/AuthContext';
import { RequiredCapability } from '../lib/rbac';
import { UnauthorizedScreen } from './UnauthorizedScreen';

interface ProtectedRouteProps {
  requiredPermission: RequiredCapability;
  areaTitle: string;
  requiredLabel: string;
  onReturnStorefront: () => void;
  children: React.ReactNode;
}

export const ProtectedRoute: React.FC<ProtectedRouteProps> = ({
  requiredPermission,
  areaTitle,
  requiredLabel,
  onReturnStorefront,
  children,
}) => {
  const { user, authReady, permissions } = useAuth();

  if (!authReady) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-14 space-y-4">
        <div className="h-10 w-64 rounded-xl bg-zinc-900 animate-pulse" />
        <div className="h-64 rounded-2xl bg-[#121216] border border-zinc-800 animate-pulse" />
      </div>
    );
  }

  const isAuthorized = Boolean(user) && Boolean(permissions[requiredPermission]);

  if (!isAuthorized) {
    return (
      <UnauthorizedScreen
        areaTitle={areaTitle}
        requiredLabel={requiredLabel}
        onReturnStorefront={onReturnStorefront}
      />
    );
  }

  return <>{children}</>;
};
