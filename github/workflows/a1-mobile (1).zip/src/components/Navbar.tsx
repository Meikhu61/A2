import React, { useMemo, useState } from 'react';
import {
  Check,
  Copy,
  KeyRound,
  LogOut,
  Menu,
  Shield,
  UserCheck,
  X,
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { AppView } from '../lib/rbac';

export type { AppView };

interface NavbarProps {
  activeView: AppView;
  onNavigate: (view: AppView) => void;
  pendingBookingsCount: number;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeView,
  onNavigate,
  pendingBookingsCount,
}) => {
  const {
    user,
    profile,
    role,
    isAdmin,
    isStaff,
    staffRecord,
    permissions,
    signingIn,
    signInWithGoogle,
    logout,
  } = useAuth();
  const [mobileOpen, setMobileOpen] = useState(false);
  const [accountOpen, setAccountOpen] = useState(false);
  const [copiedUid, setCopiedUid] = useState(false);

  // Strict role-based navigation links:
  // Ordinary customers and public visitors ONLY see Storefront and Bookings.
  const visibleNavItems = useMemo(() => {
    const items: { id: AppView; label: string }[] = [
      { id: 'storefront', label: 'Storefront' },
      { id: 'bookings', label: 'Bookings' },
    ];

    if (user && permissions.viewAnalytics) {
      items.push({ id: 'analytics', label: 'Analytics' });
    }
    if (user && permissions.manageInventory) {
      items.push({ id: 'inventory', label: 'Inventory' });
    }
    if (user && role === 'admin' && permissions.manageStaff) {
      items.push({ id: 'staff', label: 'Staff' });
    }

    return items;
  }, [user, role, permissions]);

  const roleDisplayLabel = useMemo(() => {
    if (isAdmin) return 'Admin';
    if (isStaff) return staffRecord?.staffRoleLabel || 'Staff';
    return 'Customer';
  }, [isAdmin, isStaff, staffRecord]);

  const handleNav = (view: AppView) => {
    onNavigate(view);
    setMobileOpen(false);
    setAccountOpen(false);
  };

  const handleCopyUid = async () => {
    if (!user) return;
    try {
      await navigator.clipboard.writeText(user.uid);
      setCopiedUid(true);
      setTimeout(() => setCopiedUid(false), 1800);
    } catch {
      // Ignore if clipboard blocked
    }
  };

  return (
    <header className="sticky top-0 z-50 bg-zinc-950/92 backdrop-blur-md border-b border-zinc-800/80">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-8">
        {/* Zone 1: Single-line Brand Wordmark */}
        <button
          type="button"
          onClick={() => handleNav('storefront')}
          className="font-display text-2xl font-bold tracking-wider gold-gradient-text whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-amber-400 rounded-sm"
        >
          A1 MOBILE
        </button>

        {/* Zone 2: Role-Filtered Single-line Navigation Links */}
        <nav className="hidden md:flex items-center gap-7 text-sm font-medium">
          {visibleNavItems.map((item) => {
            const isActive = activeView === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => handleNav(item.id)}
                className={`relative py-2 whitespace-nowrap shrink-0 transition-colors cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-amber-400 rounded-sm ${
                  isActive
                    ? 'text-amber-300 font-semibold'
                    : 'text-zinc-400 hover:text-zinc-100'
                }`}
              >
                <span>{item.label}</span>
                {item.id === 'bookings' && pendingBookingsCount > 0 && (
                  <span className="ml-1.5 font-mono text-xs tabular-nums text-amber-400">
                    ({pendingBookingsCount})
                  </span>
                )}
                {isActive && (
                  <span
                    aria-hidden="true"
                    className="absolute inset-x-0 -bottom-[1px] h-0.5 bg-amber-400"
                  />
                )}
              </button>
            );
          })}
        </nav>

        {/* Zone 3: 1 Primary Action / Account Popover + Mobile Menu Trigger */}
        <div className="flex items-center gap-3 shrink-0 relative">
          {user ? (
            <div className="flex items-center gap-2.5">
              <button
                type="button"
                onClick={() => setAccountOpen((prev) => !prev)}
                className="hidden sm:flex items-center gap-2 px-3 py-1.5 min-h-[38px] rounded-lg border border-zinc-800 bg-zinc-900/70 hover:border-zinc-700 text-xs text-zinc-300 whitespace-nowrap cursor-pointer transition-colors"
                title="View account role & Google Account UID"
              >
                {isAdmin ? (
                  <Shield className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                ) : isStaff ? (
                  <KeyRound className="w-3.5 h-3.5 text-sky-400 shrink-0" />
                ) : (
                  <UserCheck className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                )}
                <span className="max-w-[120px] truncate font-medium text-zinc-100">
                  {profile?.displayName || user.displayName || 'Account'}
                </span>
                <span className="text-zinc-600" aria-hidden="true">·</span>
                <span className={isAdmin ? 'text-amber-300' : isStaff ? 'text-sky-300' : 'text-zinc-400'}>
                  {roleDisplayLabel}
                </span>
              </button>

              <button
                type="button"
                onClick={() => void logout()}
                className="inline-flex items-center gap-1.5 px-4 py-2 min-h-[40px] rounded-lg border border-zinc-700 bg-zinc-900 text-zinc-200 text-xs font-semibold hover:border-amber-400/70 hover:text-white transition-colors whitespace-nowrap shrink-0 cursor-pointer"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span>Sign Out</span>
              </button>
            </div>
          ) : (
            <button
              type="button"
              disabled={signingIn}
              onClick={() => void signInWithGoogle()}
              className="inline-flex items-center justify-center px-4 py-2 min-h-[40px] rounded-lg gold-gradient-bg text-zinc-950 text-xs font-bold hover:brightness-110 transition whitespace-nowrap shrink-0 cursor-pointer disabled:opacity-60"
            >
              {signingIn ? 'Signing In...' : 'Sign In'}
            </button>
          )}

          {/* Account UID Popover */}
          {user && accountOpen && (
            <div className="hidden sm:block absolute right-0 top-12 w-80 rounded-xl bg-[#121216] border border-zinc-700 p-4 shadow-2xl space-y-3 z-50">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-white">Verified Google Account</span>
                <button
                  type="button"
                  aria-label="Close account details"
                  onClick={() => setAccountOpen(false)}
                  className="text-zinc-400 hover:text-white cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
              <div className="text-xs space-y-1 text-zinc-400">
                <p className="text-zinc-200 font-medium truncate">{user.email}</p>
                <p>
                  Access Tier:{' '}
                  <span className="text-amber-300 font-semibold">{roleDisplayLabel}</span>
                </p>
              </div>
              <div className="rounded-lg bg-zinc-950 border border-zinc-800 p-2.5 space-y-1.5">
                <div className="flex items-center justify-between text-[11px]">
                  <span className="text-zinc-400">Account UID</span>
                  <button
                    type="button"
                    onClick={() => void handleCopyUid()}
                    className="inline-flex items-center gap-1 text-amber-300 hover:underline font-medium cursor-pointer"
                  >
                    {copiedUid ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                    {copiedUid ? 'Copied' : 'Copy UID'}
                  </button>
                </div>
                <p className="font-mono text-[11px] text-zinc-200 break-all select-all">
                  {user.uid}
                </p>
              </div>
            </div>
          )}

          <button
            type="button"
            aria-label="Toggle Menu"
            aria-expanded={mobileOpen}
            onClick={() => setMobileOpen((prev) => !prev)}
            className="md:hidden p-2 min-w-[44px] min-h-[44px] flex items-center justify-center rounded-lg border border-zinc-800 text-zinc-300 hover:text-amber-300 transition-colors"
          >
            {mobileOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileOpen && (
        <div className="md:hidden border-t border-zinc-800 bg-zinc-950 px-4 py-3 space-y-1">
          {visibleNavItems.map((item) => {
            const isActive = activeView === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => handleNav(item.id)}
                className={`w-full flex items-center justify-between min-h-[44px] px-3 rounded-lg text-sm font-medium transition-colors ${
                  isActive
                    ? 'bg-zinc-900 text-amber-300 font-semibold'
                    : 'text-zinc-300 hover:bg-zinc-900/60'
                }`}
              >
                <span>{item.label}</span>
                {item.id === 'bookings' && pendingBookingsCount > 0 && (
                  <span className="font-mono text-xs tabular-nums text-amber-400">
                    {pendingBookingsCount}
                  </span>
                )}
              </button>
            );
          })}
          {user && (
            <div className="pt-2 mt-2 border-t border-zinc-800/80 px-3 py-2 text-xs text-zinc-400 space-y-1.5">
              <div className="flex items-center justify-between">
                <span className="truncate">{profile?.displayName || user.displayName}</span>
                <span className="text-amber-300 font-medium">{roleDisplayLabel}</span>
              </div>
              <div className="flex items-center justify-between gap-2 text-[11px] font-mono text-zinc-500">
                <span className="truncate">UID: {user.uid}</span>
                <button
                  type="button"
                  onClick={() => void handleCopyUid()}
                  className="text-amber-300 font-sans shrink-0 cursor-pointer"
                >
                  {copiedUid ? 'Copied' : 'Copy'}
                </button>
              </div>
            </div>
          )}
        </div>
      )}
    </header>
  );
};
