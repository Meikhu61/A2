import React, { useState } from 'react';
import { ArrowLeft, Check, Copy, Lock, ShieldAlert } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

interface UnauthorizedScreenProps {
  areaTitle: string;
  requiredLabel: string;
  onReturnStorefront: () => void;
}

export const UnauthorizedScreen: React.FC<UnauthorizedScreenProps> = ({
  areaTitle,
  requiredLabel,
  onReturnStorefront,
}) => {
  const { user, role, staffRecord, signInWithGoogle, signingIn } = useAuth();
  const [copied, setCopied] = useState(false);

  const handleCopyUid = async () => {
    if (!user) return;
    try {
      await navigator.clipboard.writeText(user.uid);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      // Fallback ignored if clipboard blocked
    }
  };

  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-14 sm:py-20">
      <div className="rounded-2xl bg-[#121216] border border-red-500/30 p-8 sm:p-12 text-center space-y-6">
        <div className="w-14 h-14 rounded-2xl bg-red-500/10 border border-red-500/30 flex items-center justify-center mx-auto">
          {user ? (
            <ShieldAlert className="w-6 h-6 text-red-400" />
          ) : (
            <Lock className="w-6 h-6 text-amber-400" />
          )}
        </div>

        <div className="space-y-2 max-w-lg mx-auto">
          <p className="text-xs font-mono uppercase tracking-widest text-red-400">
            Access Restricted · 403 Unauthorized
          </p>
          <h1 className="font-display text-3xl sm:text-4xl font-bold text-white">
            {user ? `No Access to ${areaTitle}` : 'Authorized Staff Sign-In Required'}
          </h1>
          <p className="text-sm text-zinc-400 leading-relaxed">
            {user
              ? `Your current account role (${
                  role === 'staff'
                    ? `Staff · ${staffRecord?.staffRoleLabel || 'Scoped'}`
                    : 'Customer'
                }) does not include ${requiredLabel}. Access is verified directly against A1 MOBILE security rules.`
              : `This workspace (${areaTitle}) is restricted to authorized A1 MOBILE staff and administrators.`}
          </p>
        </div>

        {user && (
          <div className="max-w-md mx-auto rounded-xl bg-zinc-950 border border-zinc-800 p-4 text-left space-y-2">
            <div className="flex items-center justify-between gap-2 text-xs">
              <span className="text-zinc-400">Verified Google Account UID</span>
              <button
                type="button"
                onClick={() => void handleCopyUid()}
                className="inline-flex items-center gap-1 text-amber-300 hover:underline font-medium cursor-pointer"
              >
                {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                {copied ? 'Copied UID' : 'Copy UID'}
              </button>
            </div>
            <p className="font-mono text-xs text-zinc-200 break-all select-all">{user.uid}</p>
            <p className="text-[11px] text-zinc-500">
              If you are an A1 MOBILE team member, share this UID with the Store Administrator to request role permissions.
            </p>
          </div>
        )}

        <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
          <button
            type="button"
            onClick={onReturnStorefront}
            className="inline-flex items-center gap-2 px-5 py-2.5 min-h-[44px] rounded-xl bg-zinc-900 border border-zinc-700 text-zinc-100 text-xs font-semibold hover:border-amber-400 transition cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4" />
            Return to Storefront
          </button>

          {!user && (
            <button
              type="button"
              disabled={signingIn}
              onClick={() => void signInWithGoogle()}
              className="inline-flex items-center justify-center px-6 py-2.5 min-h-[44px] rounded-xl gold-gradient-bg text-zinc-950 font-bold text-xs hover:brightness-110 transition cursor-pointer disabled:opacity-60"
            >
              {signingIn ? 'Signing In...' : 'Sign In With Google'}
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
