import React, { useMemo, useState } from 'react';
import {
  Check,
  Copy,
  Edit3,
  KeyRound,
  ShieldCheck,
  Trash2,
  UserCheck,
  UserPlus,
  UserX,
  X,
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { isValidFirebaseUid } from '../lib/rbac';
import {
  revokeStaffAccount,
  setStaffActiveStatus,
  upsertStaffAccount,
} from '../services/firestoreService';
import {
  STAFF_ROLE_PRESETS,
  StaffPermissions,
  StaffRecord,
  StaffRoleLabel,
} from '../types/domain';
import { UnauthorizedScreen } from './UnauthorizedScreen';

interface StaffManagementProps {
  staffList: StaffRecord[];
  loading: boolean;
  onReturnStorefront: () => void;
  onNotify: (type: 'success' | 'error' | 'info', message: string) => void;
}

const ROLE_LABELS: StaffRoleLabel[] = [
  'Store Manager',
  'Inventory Specialist',
  'Booking Coordinator',
  'Operations Staff',
];

const INITIAL_PERMS: StaffPermissions = {
  manageInventory: true,
  manageBookings: false,
  viewAnalytics: false,
};

export const StaffManagement: React.FC<StaffManagementProps> = ({
  staffList,
  loading,
  onReturnStorefront,
  onNotify,
}) => {
  const { user, role, permissions } = useAuth();

  const [uidInput, setUidInput] = useState('');
  const [nameInput, setNameInput] = useState('');
  const [emailInput, setEmailInput] = useState('');
  const [roleLabel, setRoleLabel] = useState<StaffRoleLabel>('Inventory Specialist');
  const [permsForm, setPermsForm] = useState<StaffPermissions>(INITIAL_PERMS);
  const [activeInput, setActiveInput] = useState(true);
  const [editingUid, setEditingUid] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  const [busyUid, setBusyUid] = useState<string | null>(null);
  const [confirmRevokeUid, setConfirmRevokeUid] = useState<string | null>(null);
  const [copiedUid, setCopiedUid] = useState<string | null>(null);

  const counts = useMemo(() => {
    const activeCount = staffList.filter((s) => s.active).length;
    const invCount = staffList.filter((s) => s.active && s.permissions.manageInventory).length;
    const bkCount = staffList.filter((s) => s.active && s.permissions.manageBookings).length;
    const analyticsCount = staffList.filter((s) => s.active && s.permissions.viewAnalytics).length;
    return {
      total: staffList.length,
      activeCount,
      invCount,
      bkCount,
      analyticsCount,
    };
  }, [staffList]);

  // Defensive component-level check (in addition to ProtectedRoute and Firestore rules)
  if (!user || role !== 'admin' || !permissions.manageStaff) {
    return (
      <UnauthorizedScreen
        areaTitle="Staff Management"
        requiredLabel="Store Administrator privileges"
        onReturnStorefront={onReturnStorefront}
      />
    );
  }

  const resetForm = () => {
    setEditingUid(null);
    setUidInput('');
    setNameInput('');
    setEmailInput('');
    setRoleLabel('Inventory Specialist');
    setPermsForm(STAFF_ROLE_PRESETS['Inventory Specialist']);
    setActiveInput(true);
  };

  const handleRolePresetChange = (nextRole: StaffRoleLabel) => {
    setRoleLabel(nextRole);
    setPermsForm({ ...STAFF_ROLE_PRESETS[nextRole] });
  };

  const handleEditStaff = (staff: StaffRecord) => {
    setEditingUid(staff.uid);
    setUidInput(staff.uid);
    setNameInput(staff.displayName);
    setEmailInput(staff.email);
    setRoleLabel(staff.staffRoleLabel);
    setPermsForm({ ...staff.permissions });
    setActiveInput(staff.active);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (saving) return;

    const cleanUid = uidInput.trim();
    if (!isValidFirebaseUid(cleanUid)) {
      onNotify(
        'error',
        'Enter a valid Google Account UID (alphanumeric, "-" or "_", 1–128 chars).'
      );
      return;
    }

    if (cleanUid === user.uid) {
      onNotify(
        'info',
        'Your current account is already verified as Store Administrator with full access.'
      );
      return;
    }

    const cleanName = nameInput.trim();
    if (cleanName.length < 2) {
      onNotify('error', 'Staff display name must be at least 2 characters.');
      return;
    }

    if (!permsForm.manageInventory && !permsForm.manageBookings && !permsForm.viewAnalytics) {
      onNotify('error', 'Assign at least one staff capability permission.');
      return;
    }

    setSaving(true);
    try {
      await upsertStaffAccount(
        {
          uid: cleanUid,
          displayName: cleanName,
          email: emailInput.trim(),
          staffRoleLabel: roleLabel,
          permissions: permsForm,
          active: activeInput,
        },
        user.uid
      );
      onNotify(
        'success',
        editingUid
          ? `Permissions updated for ${cleanName}.`
          : `${cleanName} authorized as ${roleLabel}.`
      );
      resetForm();
    } catch (err) {
      console.error(err);
      onNotify(
        'error',
        err instanceof Error ? err.message : 'Unable to save staff authorization.'
      );
    } finally {
      setSaving(false);
    }
  };

  const handleToggleActive = async (staff: StaffRecord) => {
    setBusyUid(staff.uid);
    try {
      await setStaffActiveStatus(staff.uid, !staff.active);
      onNotify(
        'info',
        `${staff.displayName} ${staff.active ? 'suspended' : 'reactivated'}.`
      );
    } catch (err) {
      console.error(err);
      onNotify('error', 'Failed to update staff status.');
    } finally {
      setBusyUid(null);
    }
  };

  const handleRevoke = async (staff: StaffRecord) => {
    setBusyUid(staff.uid);
    try {
      await revokeStaffAccount(staff.uid);
      setConfirmRevokeUid(null);
      if (editingUid === staff.uid) resetForm();
      onNotify('info', `Access revoked for ${staff.displayName}.`);
    } catch (err) {
      console.error(err);
      onNotify('error', 'Failed to revoke staff access.');
    } finally {
      setBusyUid(null);
    }
  };

  const handleCopy = async (val: string) => {
    try {
      await navigator.clipboard.writeText(val);
      setCopiedUid(val);
      setTimeout(() => setCopiedUid(null), 1800);
    } catch {
      // Ignore if clipboard unavailable
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-10 space-y-8">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 border-b border-zinc-800 pb-6">
        <div>
          <p className="text-xs font-semibold uppercase tracking-wider text-amber-400">
            Admin-Only Authority · Trusted Staff Registry
          </p>
          <h1 className="font-display text-3xl sm:text-4xl font-bold text-white mt-1">
            Staff & Role Permissions
          </h1>
        </div>

        <div className="rounded-xl bg-[#121216] border border-zinc-800 px-4 py-2.5 flex items-center gap-3 text-xs">
          <KeyRound className="w-4 h-4 text-amber-400 shrink-0" />
          <div className="min-w-0">
            <span className="text-zinc-400 mr-2">Admin UID:</span>
            <span className="font-mono text-zinc-200">{user.uid.slice(0, 12)}…</span>
          </div>
          <button
            type="button"
            onClick={() => void handleCopy(user.uid)}
            className="text-amber-300 hover:underline font-semibold cursor-pointer shrink-0"
          >
            {copiedUid === user.uid ? 'Copied' : 'Copy'}
          </button>
        </div>
      </div>

      {/* KPI Strip */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="rounded-2xl bg-[#121216] border border-zinc-800 p-5">
          <p className="text-xs text-zinc-400">Authorized Staff</p>
          <p className="font-mono text-2xl font-bold text-white tabular-nums mt-1">
            {counts.activeCount}
            <span className="text-xs font-normal text-zinc-500 ml-1.5">
              / {counts.total} total
            </span>
          </p>
        </div>
        <div className="rounded-2xl bg-[#121216] border border-zinc-800 p-5">
          <p className="text-xs text-zinc-400">Inventory Editors</p>
          <p className="font-mono text-2xl font-bold text-amber-300 tabular-nums mt-1">
            {counts.invCount}
          </p>
        </div>
        <div className="rounded-2xl bg-[#121216] border border-zinc-800 p-5">
          <p className="text-xs text-zinc-400">Booking Coordinators</p>
          <p className="font-mono text-2xl font-bold text-sky-400 tabular-nums mt-1">
            {counts.bkCount}
          </p>
        </div>
        <div className="rounded-2xl bg-[#121216] border border-zinc-800 p-5">
          <p className="text-xs text-zinc-400">Analytics Viewers</p>
          <p className="font-mono text-2xl font-bold text-emerald-400 tabular-nums mt-1">
            {counts.analyticsCount}
          </p>
        </div>
      </div>

      <div className="grid lg:grid-cols-12 gap-8 items-start">
        {/* Left: Add / Edit Staff Form */}
        <section className="lg:col-span-5 rounded-2xl bg-[#121216] border border-zinc-800 p-6 space-y-5">
          <div className="flex items-center justify-between border-b border-zinc-800 pb-4">
            <div className="flex items-center gap-2">
              <UserPlus className="w-4 h-4 text-amber-400" />
              <h2 className="font-display text-xl font-bold text-white">
                {editingUid ? 'Edit Staff Permissions' : 'Authorize Staff by Google UID'}
              </h2>
            </div>
            {editingUid && (
              <button
                type="button"
                onClick={resetForm}
                className="text-xs text-zinc-400 hover:text-white cursor-pointer"
              >
                Cancel Edit
              </button>
            )}
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label htmlFor="st-uid" className="block text-xs font-medium text-zinc-300 mb-1.5">
                Verified Google Account UID *
              </label>
              <input
                id="st-uid"
                type="text"
                required
                disabled={Boolean(editingUid)}
                value={uidInput}
                onChange={(e) => setUidInput(e.target.value)}
                placeholder="Paste team member Firebase Auth UID"
                className="w-full min-h-[42px] px-3.5 rounded-xl bg-zinc-950 border border-zinc-700 font-mono text-xs text-zinc-100 placeholder-zinc-500 focus:border-amber-400 focus:outline-none disabled:opacity-60"
              />
              <p className="text-[11px] text-zinc-500 mt-1">
                Team members sign in with Google once and copy their UID from the header Account badge.
              </p>
            </div>

            <div className="grid sm:grid-cols-2 gap-3">
              <div>
                <label htmlFor="st-name" className="block text-xs font-medium text-zinc-300 mb-1.5">
                  Staff Name *
                </label>
                <input
                  id="st-name"
                  type="text"
                  required
                  value={nameInput}
                  onChange={(e) => setNameInput(e.target.value)}
                  placeholder="e.g., Rohit Sharma"
                  className="w-full min-h-[42px] px-3.5 rounded-xl bg-zinc-950 border border-zinc-700 text-sm text-zinc-100 placeholder-zinc-500 focus:border-amber-400 focus:outline-none"
                />
              </div>

              <div>
                <label htmlFor="st-email" className="block text-xs font-medium text-zinc-300 mb-1.5">
                  Google Email (Note)
                </label>
                <input
                  id="st-email"
                  type="email"
                  value={emailInput}
                  onChange={(e) => setEmailInput(e.target.value)}
                  placeholder="staff@example.com"
                  className="w-full min-h-[42px] px-3.5 rounded-xl bg-zinc-950 border border-zinc-700 text-sm text-zinc-100 placeholder-zinc-500 focus:border-amber-400 focus:outline-none"
                />
              </div>
            </div>

            <div>
              <label htmlFor="st-role" className="block text-xs font-medium text-zinc-300 mb-1.5">
                Staff Role Title
              </label>
              <select
                id="st-role"
                value={roleLabel}
                onChange={(e) => handleRolePresetChange(e.target.value as StaffRoleLabel)}
                className="w-full min-h-[42px] px-3.5 rounded-xl bg-zinc-950 border border-zinc-700 text-sm text-zinc-100 focus:border-amber-400 focus:outline-none"
              >
                {ROLE_LABELS.map((rl) => (
                  <option key={rl} value={rl}>
                    {rl}
                  </option>
                ))}
              </select>
            </div>

            <div className="space-y-2.5 pt-1">
              <p className="text-xs font-medium text-zinc-300">Assigned Firestore Capabilities</p>

              <label className="flex items-start gap-3 p-3 rounded-xl bg-zinc-950 border border-zinc-800 cursor-pointer hover:border-zinc-700">
                <input
                  type="checkbox"
                  checked={permsForm.manageInventory}
                  onChange={(e) =>
                    setPermsForm((p) => ({ ...p, manageInventory: e.target.checked }))
                  }
                  className="mt-0.5 w-4 h-4 accent-amber-400"
                />
                <div className="text-xs">
                  <span className="font-semibold text-zinc-100 block">Manage Inventory</span>
                  <span className="text-zinc-400">
                    Add smartphones, edit prices, update stock counts, publish/hide SKUs.
                  </span>
                </div>
              </label>

              <label className="flex items-start gap-3 p-3 rounded-xl bg-zinc-950 border border-zinc-800 cursor-pointer hover:border-zinc-700">
                <input
                  type="checkbox"
                  checked={permsForm.manageBookings}
                  onChange={(e) =>
                    setPermsForm((p) => ({ ...p, manageBookings: e.target.checked }))
                  }
                  className="mt-0.5 w-4 h-4 accent-amber-400"
                />
                <div className="text-xs">
                  <span className="font-semibold text-zinc-100 block">Manage Customer Bookings</span>
                  <span className="text-zinc-400">
                    View full store booking queue and confirm, complete, or cancel slots.
                  </span>
                </div>
              </label>

              <label className="flex items-start gap-3 p-3 rounded-xl bg-zinc-950 border border-zinc-800 cursor-pointer hover:border-zinc-700">
                <input
                  type="checkbox"
                  checked={permsForm.viewAnalytics}
                  onChange={(e) =>
                    setPermsForm((p) => ({ ...p, viewAnalytics: e.target.checked }))
                  }
                  className="mt-0.5 w-4 h-4 accent-amber-400"
                />
                <div className="text-xs">
                  <span className="font-semibold text-zinc-100 block">View Store Analytics</span>
                  <span className="text-zinc-400">
                    Access booking volume charts and registered user analytics directory.
                  </span>
                </div>
              </label>
            </div>

            <label className="flex items-center gap-2.5 text-xs text-zinc-300 cursor-pointer pt-1">
              <input
                type="checkbox"
                checked={activeInput}
                onChange={(e) => setActiveInput(e.target.checked)}
                className="w-4 h-4 accent-amber-400"
              />
              Account active immediately
            </label>

            <button
              type="submit"
              disabled={saving}
              className="w-full min-h-[46px] rounded-xl gold-gradient-bg text-zinc-950 font-bold text-sm hover:brightness-110 transition cursor-pointer disabled:opacity-60"
            >
              {saving
                ? 'Saving Authorization...'
                : editingUid
                ? 'Update Staff Permissions'
                : 'Authorize Staff Member'}
            </button>
          </form>
        </section>

        {/* Right: Authorized Staff Directory */}
        <section className="lg:col-span-7 rounded-2xl bg-[#121216] border border-zinc-800 overflow-hidden">
          <div className="p-5 sm:p-6 border-b border-zinc-800 flex items-center justify-between gap-3">
            <div>
              <h2 className="font-display text-xl font-bold text-white">
                Authorized Staff Accounts
              </h2>
              <p className="text-xs text-zinc-400 mt-0.5">
                Staff cannot promote themselves or access Staff Management. Revocation takes effect in real time.
              </p>
            </div>
            <ShieldCheck className="w-5 h-5 text-amber-400 shrink-0" />
          </div>

          {loading ? (
            <div className="p-6 space-y-3">
              {[1, 2, 3].map((n) => (
                <div key={n} className="h-20 rounded-xl bg-zinc-900/70 animate-pulse" />
              ))}
            </div>
          ) : staffList.length === 0 ? (
            <div className="p-12 text-center space-y-2">
              <UserCheck className="w-8 h-8 text-zinc-600 mx-auto" />
              <p className="text-base font-semibold text-zinc-200">No staff accounts added yet</p>
              <p className="text-sm text-zinc-400 max-w-md mx-auto">
                Add verified Google Account UIDs on the left to delegate inventory, bookings, or analytics access without sharing admin credentials.
              </p>
            </div>
          ) : (
            <div className="divide-y divide-zinc-800/80">
              {staffList.map((staff) => {
                const isBusy = busyUid === staff.uid;
                const activePermissions = [
                  staff.permissions.manageInventory && 'Inventory',
                  staff.permissions.manageBookings && 'Bookings',
                  staff.permissions.viewAnalytics && 'Analytics',
                ].filter(Boolean) as string[];

                return (
                  <div
                    key={staff.uid}
                    className={`p-5 space-y-3 transition-colors ${
                      !staff.active ? 'opacity-65 bg-zinc-950/40' : 'hover:bg-zinc-900/30'
                    }`}
                  >
                    <div className="flex flex-wrap items-start justify-between gap-3">
                      <div className="space-y-1 min-w-0">
                        <div className="flex items-center gap-2 flex-wrap">
                          <h3 className="font-display text-lg font-bold text-white truncate">
                            {staff.displayName}
                          </h3>
                          <span className="text-xs font-medium text-amber-300">
                            {staff.staffRoleLabel}
                          </span>
                          <span
                            className={`text-[11px] font-mono ${
                              staff.active ? 'text-emerald-400' : 'text-red-400'
                            }`}
                          >
                            {staff.active ? '· Active' : '· Suspended'}
                          </span>
                        </div>
                        <div className="flex items-center gap-2 text-xs text-zinc-400 font-mono">
                          <span className="truncate max-w-[240px]" title={staff.uid}>
                            UID: {staff.uid}
                          </span>
                          <button
                            type="button"
                            aria-label={`Copy UID for ${staff.displayName}`}
                            onClick={() => void handleCopy(staff.uid)}
                            className="text-zinc-400 hover:text-amber-300 cursor-pointer"
                          >
                            {copiedUid === staff.uid ? (
                              <Check className="w-3.5 h-3.5 text-emerald-400" />
                            ) : (
                              <Copy className="w-3.5 h-3.5" />
                            )}
                          </button>
                          {staff.email && (
                            <span className="font-sans text-zinc-500 truncate">
                              · {staff.email}
                            </span>
                          )}
                        </div>
                      </div>

                      <div className="flex items-center gap-2 shrink-0">
                        <button
                          type="button"
                          onClick={() => handleEditStaff(staff)}
                          className="inline-flex items-center gap-1 px-2.5 py-1.5 min-h-[34px] rounded-lg bg-zinc-900 border border-zinc-700 text-xs text-zinc-200 hover:border-amber-400 cursor-pointer"
                        >
                          <Edit3 className="w-3.5 h-3.5" />
                          Edit
                        </button>

                        <button
                          type="button"
                          disabled={isBusy}
                          onClick={() => void handleToggleActive(staff)}
                          className="inline-flex items-center gap-1 px-2.5 py-1.5 min-h-[34px] rounded-lg bg-zinc-900 border border-zinc-700 text-xs text-zinc-200 hover:border-zinc-500 cursor-pointer disabled:opacity-50"
                        >
                          {staff.active ? (
                            <>
                              <UserX className="w-3.5 h-3.5 text-amber-300" />
                              Suspend
                            </>
                          ) : (
                            <>
                              <UserCheck className="w-3.5 h-3.5 text-emerald-400" />
                              Activate
                            </>
                          )}
                        </button>

                        {confirmRevokeUid === staff.uid ? (
                          <div className="inline-flex items-center gap-1">
                            <button
                              type="button"
                              disabled={isBusy}
                              onClick={() => void handleRevoke(staff)}
                              className="px-2.5 py-1.5 min-h-[34px] rounded-lg bg-red-500 text-white text-xs font-semibold cursor-pointer"
                            >
                              Revoke
                            </button>
                            <button
                              type="button"
                              aria-label="Cancel revoke"
                              onClick={() => setConfirmRevokeUid(null)}
                              className="p-1.5 min-h-[34px] rounded-lg bg-zinc-900 border border-zinc-700 text-zinc-300 cursor-pointer"
                            >
                              <X className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        ) : (
                          <button
                            type="button"
                            aria-label={`Revoke access for ${staff.displayName}`}
                            onClick={() => setConfirmRevokeUid(staff.uid)}
                            className="p-2 min-h-[34px] rounded-lg bg-zinc-900 border border-zinc-700 text-zinc-400 hover:text-red-400 hover:border-red-400/60 cursor-pointer"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>
                    </div>

                    <div className="flex flex-wrap items-center gap-3 text-xs text-zinc-400 pt-1">
                      <span className="text-zinc-500">Permissions:</span>
                      {activePermissions.length > 0 ? (
                        <span className="font-mono text-zinc-200">
                          {activePermissions.join(' · ')}
                        </span>
                      ) : (
                        <span className="text-zinc-500">None assigned</span>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </section>
      </div>
    </div>
  );
};
