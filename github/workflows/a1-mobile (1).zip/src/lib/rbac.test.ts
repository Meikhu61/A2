import assert from 'node:assert/strict';
import {
  canAccessView,
  isValidFirebaseUid,
  parseHashToView,
  resolveRoleAndCapabilities,
} from './rbac.ts';
import { StaffRecord } from '../types/domain.ts';

function runRbacTests() {
  // 1. Ordinary Customer (even with verified email, no admin/staff registry entry)
  const customer = resolveRoleAndCapabilities({
    email: 'customer@example.com',
    emailVerified: true,
    hasAdminDoc: false,
    staffRecord: null,
  });
  assert.equal(customer.role, 'customer');
  assert.equal(customer.isAdmin, false);
  assert.equal(customer.isStaff, false);
  assert.deepEqual(customer.permissions, {
    manageInventory: false,
    manageBookings: false,
    viewAnalytics: false,
    manageStaff: false,
  });

  // Customer cannot access any protected route, even when entered manually via hash
  assert.equal(canAccessView('storefront', true, customer.permissions), true);
  assert.equal(canAccessView('bookings', true, customer.permissions), true);
  assert.equal(canAccessView('analytics', true, customer.permissions), false);
  assert.equal(canAccessView('inventory', true, customer.permissions), false);
  assert.equal(canAccessView('staff', true, customer.permissions), false);

  assert.equal(parseHashToView('#inventory', customer.permissions), 'inventory');
  assert.equal(
    canAccessView(parseHashToView('#admin', customer.permissions), true, customer.permissions),
    false
  );
  assert.equal(
    canAccessView(parseHashToView('#dashboard', customer.permissions), true, customer.permissions),
    false
  );

  // Unauthenticated visitor cannot access protected routes
  assert.equal(canAccessView('analytics', false, customer.permissions), false);
  assert.equal(canAccessView('inventory', false, customer.permissions), false);
  assert.equal(canAccessView('staff', false, customer.permissions), false);

  // 2. Staff Member (Scoped permissions: Inventory + Bookings, NO Analytics, NO Staff Management)
  const scopedStaffDoc: StaffRecord = {
    uid: 'staff_rohit_123',
    displayName: 'Rohit',
    email: 'rohit@a1mobile.in',
    staffRoleLabel: 'Operations Staff',
    permissions: {
      manageInventory: true,
      manageBookings: true,
      viewAnalytics: false,
    },
    active: true,
    createdBy: 'admin_uid_1',
  };

  const staff = resolveRoleAndCapabilities({
    email: 'rohit@a1mobile.in',
    emailVerified: true,
    hasAdminDoc: false,
    staffRecord: scopedStaffDoc,
  });
  assert.equal(staff.role, 'staff');
  assert.equal(staff.isAdmin, false);
  assert.equal(staff.isStaff, true);
  assert.deepEqual(staff.permissions, {
    manageInventory: true,
    manageBookings: true,
    viewAnalytics: false,
    manageStaff: false,
  });
  assert.equal(canAccessView('inventory', true, staff.permissions), true);
  assert.equal(canAccessView('analytics', true, staff.permissions), false);
  assert.equal(canAccessView('staff', true, staff.permissions), false);

  // 3. Suspended Staff Member loses all permissions immediately
  const suspendedStaff = resolveRoleAndCapabilities({
    email: 'rohit@a1mobile.in',
    emailVerified: true,
    hasAdminDoc: false,
    staffRecord: { ...scopedStaffDoc, active: false },
  });
  assert.equal(suspendedStaff.role, 'customer');
  assert.equal(canAccessView('inventory', true, suspendedStaff.permissions), false);

  // 4. Unverified Bootstrap Admin Email Spoof is rejected
  const unverifiedAdmin = resolveRoleAndCapabilities({
    email: 'sanayaikhom62@gmail.com',
    emailVerified: false,
    hasAdminDoc: false,
    staffRecord: null,
  });
  assert.equal(unverifiedAdmin.role, 'customer');
  assert.equal(unverifiedAdmin.isAdmin, false);

  // 5. Verified Bootstrap Admin gets full access
  const admin = resolveRoleAndCapabilities({
    email: 'sanayaikhom62@gmail.com',
    emailVerified: true,
    hasAdminDoc: false,
    staffRecord: null,
  });
  assert.equal(admin.role, 'admin');
  assert.equal(admin.isAdmin, true);
  assert.equal(admin.isBootstrapAdmin, true);
  assert.deepEqual(admin.permissions, {
    manageInventory: true,
    manageBookings: true,
    viewAnalytics: true,
    manageStaff: true,
  });
  assert.equal(canAccessView('analytics', true, admin.permissions), true);
  assert.equal(canAccessView('inventory', true, admin.permissions), true);
  assert.equal(canAccessView('staff', true, admin.permissions), true);

  // 6. UID validation for Staff Management
  assert.equal(isValidFirebaseUid('RyL4oAKMnENZqfI8hjcdJz3bW4T2'), true);
  assert.equal(isValidFirebaseUid('invalid/uid/with/slashes'), false);
  assert.equal(isValidFirebaseUid(''), false);

  console.log('All RBAC role resolution and route guard checks passed.');
}

runRbacTests();
