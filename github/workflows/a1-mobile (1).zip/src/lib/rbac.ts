import {
  AccessCapabilities,
  BOOTSTRAP_ADMIN_EMAIL,
  SCHEMA_LIMITS,
  StaffRecord,
  UserRole,
} from '../types/domain';

export type AppView = 'storefront' | 'bookings' | 'analytics' | 'inventory' | 'staff';

export type RequiredCapability = keyof AccessCapabilities;

export const EMPTY_CAPABILITIES: AccessCapabilities = {
  manageInventory: false,
  manageBookings: false,
  viewAnalytics: false,
  manageStaff: false,
};

export interface RoleResolutionInput {
  email?: string | null;
  emailVerified?: boolean;
  hasAdminDoc: boolean;
  staffRecord: StaffRecord | null;
}

export interface RoleResolutionResult {
  role: UserRole;
  isAdmin: boolean;
  isBootstrapAdmin: boolean;
  isStaff: boolean;
  permissions: AccessCapabilities;
}

/**
 * Resolves a user's authoritative role and permissions strictly from verified identity
 * tokens and trusted admin/staff registries — never from customer-editable user profiles.
 */
export function resolveRoleAndCapabilities(
  input: RoleResolutionInput
): RoleResolutionResult {
  const isBootstrapAdmin =
    Boolean(input.emailVerified) &&
    input.email?.toLowerCase() === BOOTSTRAP_ADMIN_EMAIL;

  const isVerified = Boolean(input.emailVerified);
  const isTrustedAdmin = isBootstrapAdmin || (isVerified && input.hasAdminDoc);

  if (isTrustedAdmin) {
    return {
      role: 'admin',
      isAdmin: true,
      isBootstrapAdmin,
      isStaff: false,
      permissions: {
        manageInventory: true,
        manageBookings: true,
        viewAnalytics: true,
        manageStaff: true,
      },
    };
  }

  if (isVerified && input.staffRecord && input.staffRecord.active) {
    return {
      role: 'staff',
      isAdmin: false,
      isBootstrapAdmin: false,
      isStaff: true,
      permissions: {
        manageInventory: Boolean(input.staffRecord.permissions.manageInventory),
        manageBookings: Boolean(input.staffRecord.permissions.manageBookings),
        viewAnalytics: Boolean(input.staffRecord.permissions.viewAnalytics),
        manageStaff: false, // Staff may NEVER manage other staff or escalate privileges
      },
    };
  }

  return {
    role: 'customer',
    isAdmin: false,
    isBootstrapAdmin: false,
    isStaff: false,
    permissions: { ...EMPTY_CAPABILITIES },
  };
}

export function getRequiredCapabilityForView(
  view: AppView
): RequiredCapability | null {
  switch (view) {
    case 'analytics':
      return 'viewAnalytics';
    case 'inventory':
      return 'manageInventory';
    case 'staff':
      return 'manageStaff';
    default:
      return null;
  }
}

export function canAccessView(
  view: AppView,
  isAuthenticated: boolean,
  permissions: AccessCapabilities
): boolean {
  const required = getRequiredCapabilityForView(view);
  if (!required) return true;
  if (!isAuthenticated) return false;
  return Boolean(permissions[required]);
}

export function parseHashToView(
  hash: string,
  permissions: AccessCapabilities = EMPTY_CAPABILITIES
): AppView {
  const clean = hash.replace(/^#\/?/, '').trim().toLowerCase();
  if (clean === 'bookings') return 'bookings';
  if (clean === 'analytics') return 'analytics';
  if (clean === 'inventory') return 'inventory';
  if (clean === 'staff') return 'staff';
  if (clean === 'admin' || clean === 'dashboard') {
    if (permissions.viewAnalytics) return 'analytics';
    if (permissions.manageInventory) return 'inventory';
    if (permissions.manageStaff) return 'staff';
    return 'analytics';
  }
  return 'storefront';
}

export function isValidFirebaseUid(uid: string): boolean {
  const trimmed = uid.trim();
  return (
    trimmed.length >= 1 &&
    trimmed.length <= SCHEMA_LIMITS.ID_MAX &&
    SCHEMA_LIMITS.ID_PATTERN.test(trimmed)
  );
}
