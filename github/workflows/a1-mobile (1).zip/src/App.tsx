import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { CheckCircle2, Info, MessageCircle, Phone, X, AlertCircle } from 'lucide-react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { AppView, Navbar } from './components/Navbar';
import { StorefrontView } from './components/StorefrontView';
import { BookingPrefill, BookingSystem } from './components/BookingSystem';
import { AnalyticsDashboard } from './components/AnalyticsDashboard';
import { InventoryManager } from './components/InventoryManager';
import { StaffManagement } from './components/StaffManagement';
import { ProtectedRoute } from './components/ProtectedRoute';
import { parseHashToView } from './lib/rbac';
import {
  seedDefaultInventory,
  subscribeBookingMetrics,
  subscribeBookings,
  subscribeInventory,
  subscribeStaffAccounts,
  subscribeUserProfiles,
} from './services/firestoreService';
import {
  BookingMetric,
  BookingRecord,
  DEFAULT_CATALOG,
  InventoryItem,
  StaffRecord,
  ToastNotice,
  UserProfile,
} from './types/domain';

const AppContent: React.FC = () => {
  const { user, role, isAdmin, permissions, authReady, authError } = useAuth();
  const [activeView, setActiveView] = useState<AppView>(() =>
    parseHashToView(window.location.hash)
  );

  const [inventoryDocs, setInventoryDocs] = useState<InventoryItem[]>([]);
  const [inventoryLoaded, setInventoryLoaded] = useState(false);

  const [profiles, setProfiles] = useState<UserProfile[]>([]);
  const [bookingMetrics, setBookingMetrics] = useState<BookingMetric[]>([]);
  const [bookings, setBookings] = useState<BookingRecord[]>([]);
  const [staffList, setStaffList] = useState<StaffRecord[]>([]);
  const [loadingBookings, setLoadingBookings] = useState(false);
  const [loadingAnalytics, setLoadingAnalytics] = useState(false);
  const [loadingStaff, setLoadingStaff] = useState(false);

  const [bookingPrefill, setBookingPrefill] = useState<BookingPrefill | null>(null);
  const [toasts, setToasts] = useState<ToastNotice[]>([]);
  const seededRef = useRef(false);

  const notify = useCallback((type: ToastNotice['type'], message: string) => {
    const id = `${Date.now()}_${Math.random().toString(36).slice(2, 6)}`;
    setToasts((prev) => [...prev.slice(-2), { id, type, message }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 4200);
  }, []);

  const navigateTo = useCallback((view: AppView) => {
    setActiveView(view);
    const targetHash = view === 'storefront' ? '#storefront' : `#${view}`;
    if (window.location.hash !== targetHash) {
      window.history.pushState(null, '', targetHash);
    }
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, []);

  // Protect and handle direct/manual URL hash routes (e.g. #analytics, #inventory, #staff, #admin, #dashboard)
  useEffect(() => {
    const handleHashChange = () => {
      setActiveView(parseHashToView(window.location.hash, permissions));
    };
    window.addEventListener('hashchange', handleHashChange);
    return () => window.removeEventListener('hashchange', handleHashChange);
  }, [permissions]);

  useEffect(() => {
    if (authError) {
      notify('error', authError);
    }
  }, [authError, notify]);

  // Live Inventory Subscription (Public only reads published; Inventory Staff & Admins can read drafts too)
  useEffect(() => {
    if (!authReady) return;
    const canViewUnpublished = Boolean(user && permissions.manageInventory);
    const unsub = subscribeInventory(
      canViewUnpublished,
      (items) => {
        setInventoryDocs(items);
        setInventoryLoaded(true);
      },
      () => {
        setInventoryLoaded(true);
      }
    );
    return () => unsub();
  }, [authReady, user, permissions.manageInventory]);

  // Auto-seed initial catalog into Firestore once when an Admin or Inventory Staff logs in and inventory is empty
  useEffect(() => {
    if (
      authReady &&
      user &&
      permissions.manageInventory &&
      inventoryLoaded &&
      inventoryDocs.length === 0 &&
      !seededRef.current
    ) {
      seededRef.current = true;
      void seedDefaultInventory(user.uid).catch((err) => {
        console.error('Auto-seed skipped:', err);
      });
    }
  }, [authReady, user, permissions.manageInventory, inventoryLoaded, inventoryDocs.length]);

  // Customer / Booking-Staff Bookings Subscription (Customer sees own; Booking Staff & Admin see all)
  useEffect(() => {
    if (!authReady || !user) {
      setBookings([]);
      setLoadingBookings(false);
      return;
    }

    setLoadingBookings(true);
    const unsubBookings = subscribeBookings(
      user.uid,
      Boolean(permissions.manageBookings),
      (data) => {
        setBookings(data);
        setLoadingBookings(false);
      },
      () => {
        setLoadingBookings(false);
      }
    );

    return () => unsubBookings();
  }, [authReady, user, permissions.manageBookings]);

  // Restricted Store Analytics Subscriptions (Only authorized viewAnalytics staff & admins)
  useEffect(() => {
    if (!authReady || !user || !permissions.viewAnalytics) {
      setProfiles([]);
      setBookingMetrics([]);
      setLoadingAnalytics(false);
      return;
    }

    setLoadingAnalytics(true);
    let profilesDone = false;
    let metricsDone = false;
    const markDone = () => {
      if (profilesDone && metricsDone) setLoadingAnalytics(false);
    };

    const unsubProfiles = subscribeUserProfiles(
      (data) => {
        setProfiles(data);
        profilesDone = true;
        markDone();
      },
      () => {
        profilesDone = true;
        markDone();
      }
    );

    const unsubMetrics = subscribeBookingMetrics(
      (data) => {
        setBookingMetrics(data);
        metricsDone = true;
        markDone();
      },
      () => {
        metricsDone = true;
        markDone();
      }
    );

    return () => {
      unsubProfiles();
      unsubMetrics();
    };
  }, [authReady, user, permissions.viewAnalytics]);

  // Admin-Only Staff Registry Subscription
  useEffect(() => {
    if (!authReady || !user || role !== 'admin' || !permissions.manageStaff) {
      setStaffList([]);
      setLoadingStaff(false);
      return;
    }

    setLoadingStaff(true);
    const unsubStaff = subscribeStaffAccounts(
      (data) => {
        setStaffList(data);
        setLoadingStaff(false);
      },
      () => {
        setLoadingStaff(false);
      }
    );

    return () => unsubStaff();
  }, [authReady, user, role, permissions.manageStaff]);

  // Show live Firestore items when available, or curated catalog preview prior to initial admin seed
  const displayedInventory = useMemo<InventoryItem[]>(() => {
    if (inventoryDocs.length > 0) return inventoryDocs;
    return DEFAULT_CATALOG.map((item) => ({ ...item, createdAt: null, updatedAt: null }));
  }, [inventoryDocs]);

  const pendingBookingsCount = useMemo(
    () => bookings.filter((b) => b.status === 'pending' || b.status === 'confirmed').length,
    [bookings]
  );

  const handleBookDevice = useCallback(
    (item: InventoryItem) => {
      setBookingPrefill({
        bookingType: 'buy_reserve',
        deviceId: item.id,
        deviceTitle: `${item.name} (${item.storage})`,
        brandCategory: item.brand,
        estimatedValue: item.price,
      });
      navigateTo('bookings');
    },
    [navigateTo]
  );

  const handleStartExchange = useCallback(
    (prefill: {
      bookingType: 'sell_device' | 'exchange_upgrade';
      tradeInDevice: string;
      deviceTitle: string;
      brandCategory: 'iphone' | 'samsung' | 'android' | 'general';
      estimatedValue: number;
    }) => {
      setBookingPrefill(prefill);
      navigateTo('bookings');
    },
    [navigateTo]
  );

  const returnToStorefront = useCallback(() => {
    navigateTo('storefront');
  }, [navigateTo]);

  return (
    <div className="min-h-screen bg-zinc-950 text-zinc-100 flex flex-col pb-16 md:pb-0">
      <Navbar
        activeView={activeView}
        onNavigate={navigateTo}
        pendingBookingsCount={pendingBookingsCount}
      />

      <main className="flex-1">
        {activeView === 'storefront' && (
          <StorefrontView
            inventory={displayedInventory}
            onBookDevice={handleBookDevice}
            onStartExchange={handleStartExchange}
            onOpenBookings={() => navigateTo('bookings')}
          />
        )}

        {activeView === 'bookings' && (
          <BookingSystem
            inventory={displayedInventory}
            bookings={bookings}
            loadingBookings={loadingBookings}
            prefill={bookingPrefill}
            onClearPrefill={() => setBookingPrefill(null)}
            onNotify={notify}
          />
        )}

        {activeView === 'analytics' && (
          <ProtectedRoute
            requiredPermission="viewAnalytics"
            areaTitle="Store Analytics"
            requiredLabel="Store Analytics permission"
            onReturnStorefront={returnToStorefront}
          >
            <AnalyticsDashboard
              profiles={profiles}
              metrics={bookingMetrics}
              inventory={displayedInventory}
              loading={loadingAnalytics}
              onReturnStorefront={returnToStorefront}
              onNotify={notify}
            />
          </ProtectedRoute>
        )}

        {activeView === 'inventory' && (
          <ProtectedRoute
            requiredPermission="manageInventory"
            areaTitle="Inventory Management"
            requiredLabel="Inventory Management permission"
            onReturnStorefront={returnToStorefront}
          >
            <InventoryManager
              inventory={displayedInventory}
              loading={!inventoryLoaded}
              isLiveSynced={inventoryDocs.length > 0}
              onBookDevice={handleBookDevice}
              onReturnStorefront={returnToStorefront}
              onNotify={notify}
            />
          </ProtectedRoute>
        )}

        {activeView === 'staff' && (
          <ProtectedRoute
            requiredPermission="manageStaff"
            areaTitle="Staff Management"
            requiredLabel="Store Administrator privileges"
            onReturnStorefront={returnToStorefront}
          >
            <StaffManagement
              staffList={staffList}
              loading={loadingStaff}
              onReturnStorefront={returnToStorefront}
              onNotify={notify}
            />
          </ProtectedRoute>
        )}
      </main>

      {/* Mobile Compact Sticky Bar (<= 15% viewport cap) */}
      <div className="md:hidden fixed bottom-0 inset-x-0 z-40 bg-zinc-950/95 backdrop-blur-md border-t border-zinc-800 px-3 py-2">
        <div className="grid grid-cols-2 gap-2.5 max-w-md mx-auto">
          <a
            href="tel:9612332925"
            className="flex items-center justify-center gap-1.5 min-h-[40px] rounded-lg bg-zinc-900 border border-zinc-700 text-white font-semibold text-xs"
          >
            <Phone className="w-3.5 h-3.5 text-amber-400" />
            Call 9612332925
          </a>
          <a
            href="https://wa.me/919612332925?text=Hi%20A1%20MOBILE!"
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center justify-center gap-1.5 min-h-[40px] rounded-lg gold-gradient-bg text-zinc-950 font-bold text-xs"
          >
            <MessageCircle className="w-3.5 h-3.5" />
            WhatsApp Store
          </a>
        </div>
      </div>

      {/* Toast Notifications */}
      {toasts.length > 0 && (
        <div className="fixed bottom-16 md:bottom-6 right-4 z-50 space-y-2 max-w-sm w-[calc(100%-2rem)]">
          {toasts.map((t) => (
            <div
              key={t.id}
              className={`rounded-xl border px-4 py-3 text-xs font-medium shadow-xl flex items-center justify-between gap-3 bg-zinc-900 ${
                t.type === 'error'
                  ? 'border-red-500/50 text-red-200'
                  : t.type === 'success'
                  ? 'border-emerald-500/50 text-emerald-200'
                  : 'border-amber-500/50 text-amber-200'
              }`}
            >
              <div className="flex items-center gap-2">
                {t.type === 'error' ? (
                  <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />
                ) : t.type === 'success' ? (
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                ) : (
                  <Info className="w-4 h-4 text-amber-400 shrink-0" />
                )}
                <span>{t.message}</span>
              </div>
              <button
                type="button"
                aria-label="Dismiss notification"
                onClick={() => setToasts((prev) => prev.filter((item) => item.id !== t.id))}
                className="text-zinc-400 hover:text-white cursor-pointer"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}
